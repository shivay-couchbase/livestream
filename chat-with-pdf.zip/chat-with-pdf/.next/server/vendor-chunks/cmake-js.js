"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/cmake-js";
exports.ids = ["vendor-chunks/cmake-js"];
exports.modules = {

/***/ "(rsc)/./node_modules/cmake-js/package.json":
/*!********************************************!*\
  !*** ./node_modules/cmake-js/package.json ***!
  \********************************************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"name":"cmake-js","description":"CMake.js - a Node.js native addon build tool","license":"MIT","keywords":["native","addon","module","c","c++","bindings","build","buildtools","cmake","nw.js","electron","boost","nan","napi","node-api","node-addon-api"],"main":"lib","version":"7.3.0","author":"Gábor Mező aka unbornchikken","maintainers":[{"name":"Julian Waller","email":"git@julusian.co.uk","url":"https://github.com/julusian/"}],"repository":{"type":"git","url":"git://github.com/cmake-js/cmake-js.git"},"bin":{"cmake-js":"./bin/cmake-js"},"engines":{"node":">= 14.15.0"},"dependencies":{"axios":"^1.6.5","debug":"^4","fs-extra":"^11.2.0","lodash.isplainobject":"^4.0.6","memory-stream":"^1.0.0","node-api-headers":"^1.1.0","npmlog":"^6.0.2","rc":"^1.2.7","semver":"^7.5.4","tar":"^6.2.0","url-join":"^4.0.1","which":"^2.0.2","yargs":"^17.7.2"},"devDependencies":{"mocha":"*","nan":"^2.18.0","node-addon-api":"^6.1.0"},"scripts":{"test":"mocha tests","lint":"eslint lib bin/cmake-js tests"},"files":["lib","bin","*.md","bindings.js","bindings.d.ts"]}');

/***/ })

};
;