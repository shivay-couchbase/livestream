/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/chat/route";
exports.ids = ["app/api/chat/route"];
exports.modules = {

/***/ "(rsc)/./node_modules/couchbase/dist sync recursive":
/*!*******************************************!*\
  !*** ./node_modules/couchbase/dist/ sync ***!
  \*******************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "(rsc)/./node_modules/couchbase/dist sync recursive";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "child_process":
/*!********************************!*\
  !*** external "child_process" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("child_process");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "module":
/*!*************************!*\
  !*** external "module" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("module");

/***/ }),

/***/ "node:crypto":
/*!******************************!*\
  !*** external "node:crypto" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:crypto");

/***/ }),

/***/ "node:fs":
/*!**************************!*\
  !*** external "node:fs" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ "node:stream":
/*!******************************!*\
  !*** external "node:stream" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ "node:stream/web":
/*!**********************************!*\
  !*** external "node:stream/web" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "punycode":
/*!***************************!*\
  !*** external "punycode" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("punycode");

/***/ }),

/***/ "querystring":
/*!******************************!*\
  !*** external "querystring" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "worker_threads":
/*!*********************************!*\
  !*** external "worker_threads" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fchat%2Froute&page=%2Fapi%2Fchat%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fchat%2Froute.ts&appDir=%2FUsers%2Fshivaylamba%2FDesktop%2Fcb-projects%2Flivestream-new%2Fchat-with-pdf%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fshivaylamba%2FDesktop%2Fcb-projects%2Flivestream-new%2Fchat-with-pdf&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fchat%2Froute&page=%2Fapi%2Fchat%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fchat%2Froute.ts&appDir=%2FUsers%2Fshivaylamba%2FDesktop%2Fcb-projects%2Flivestream-new%2Fchat-with-pdf%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fshivaylamba%2FDesktop%2Fcb-projects%2Flivestream-new%2Fchat-with-pdf&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _Users_shivaylamba_Desktop_cb_projects_livestream_new_chat_with_pdf_src_app_api_chat_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/chat/route.ts */ \"(rsc)/./src/app/api/chat/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/chat/route\",\n        pathname: \"/api/chat\",\n        filename: \"route\",\n        bundlePath: \"app/api/chat/route\"\n    },\n    resolvedPagePath: \"/Users/shivaylamba/Desktop/cb-projects/livestream-new/chat-with-pdf/src/app/api/chat/route.ts\",\n    nextConfigOutput,\n    userland: _Users_shivaylamba_Desktop_cb_projects_livestream_new_chat_with_pdf_src_app_api_chat_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks } = routeModule;\nconst originalPathname = \"/api/chat/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZjaGF0JTJGcm91dGUmcGFnZT0lMkZhcGklMkZjaGF0JTJGcm91dGUmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGYXBpJTJGY2hhdCUyRnJvdXRlLnRzJmFwcERpcj0lMkZVc2VycyUyRnNoaXZheWxhbWJhJTJGRGVza3RvcCUyRmNiLXByb2plY3RzJTJGbGl2ZXN0cmVhbS1uZXclMkZjaGF0LXdpdGgtcGRmJTJGc3JjJTJGYXBwJnBhZ2VFeHRlbnNpb25zPXRzeCZwYWdlRXh0ZW5zaW9ucz10cyZwYWdlRXh0ZW5zaW9ucz1qc3gmcGFnZUV4dGVuc2lvbnM9anMmcm9vdERpcj0lMkZVc2VycyUyRnNoaXZheWxhbWJhJTJGRGVza3RvcCUyRmNiLXByb2plY3RzJTJGbGl2ZXN0cmVhbS1uZXclMkZjaGF0LXdpdGgtcGRmJmlzRGV2PXRydWUmdHNjb25maWdQYXRoPXRzY29uZmlnLmpzb24mYmFzZVBhdGg9JmFzc2V0UHJlZml4PSZuZXh0Q29uZmlnT3V0cHV0PSZwcmVmZXJyZWRSZWdpb249Jm1pZGRsZXdhcmVDb25maWc9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBc0c7QUFDdkM7QUFDYztBQUM2QztBQUMxSDtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsZ0hBQW1CO0FBQzNDO0FBQ0EsY0FBYyx5RUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsWUFBWTtBQUNaLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxRQUFRLGlFQUFpRTtBQUN6RTtBQUNBO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ3VIOztBQUV2SCIsInNvdXJjZXMiOlsid2VicGFjazovL2NoYXQtd2l0aC1wZGYvPzMzNjEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBwUm91dGVSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1raW5kXCI7XG5pbXBvcnQgeyBwYXRjaEZldGNoIGFzIF9wYXRjaEZldGNoIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvbGliL3BhdGNoLWZldGNoXCI7XG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiL1VzZXJzL3NoaXZheWxhbWJhL0Rlc2t0b3AvY2ItcHJvamVjdHMvbGl2ZXN0cmVhbS1uZXcvY2hhdC13aXRoLXBkZi9zcmMvYXBwL2FwaS9jaGF0L3JvdXRlLnRzXCI7XG4vLyBXZSBpbmplY3QgdGhlIG5leHRDb25maWdPdXRwdXQgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IG5leHRDb25maWdPdXRwdXQgPSBcIlwiXG5jb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBBcHBSb3V0ZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUk9VVEUsXG4gICAgICAgIHBhZ2U6IFwiL2FwaS9jaGF0L3JvdXRlXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9hcGkvY2hhdFwiLFxuICAgICAgICBmaWxlbmFtZTogXCJyb3V0ZVwiLFxuICAgICAgICBidW5kbGVQYXRoOiBcImFwcC9hcGkvY2hhdC9yb3V0ZVwiXG4gICAgfSxcbiAgICByZXNvbHZlZFBhZ2VQYXRoOiBcIi9Vc2Vycy9zaGl2YXlsYW1iYS9EZXNrdG9wL2NiLXByb2plY3RzL2xpdmVzdHJlYW0tbmV3L2NoYXQtd2l0aC1wZGYvc3JjL2FwcC9hcGkvY2hhdC9yb3V0ZS50c1wiLFxuICAgIG5leHRDb25maWdPdXRwdXQsXG4gICAgdXNlcmxhbmRcbn0pO1xuLy8gUHVsbCBvdXQgdGhlIGV4cG9ydHMgdGhhdCB3ZSBuZWVkIHRvIGV4cG9zZSBmcm9tIHRoZSBtb2R1bGUuIFRoaXMgc2hvdWxkXG4vLyBiZSBlbGltaW5hdGVkIHdoZW4gd2UndmUgbW92ZWQgdGhlIG90aGVyIHJvdXRlcyB0byB0aGUgbmV3IGZvcm1hdC4gVGhlc2Vcbi8vIGFyZSB1c2VkIHRvIGhvb2sgaW50byB0aGUgcm91dGUuXG5jb25zdCB7IHJlcXVlc3RBc3luY1N0b3JhZ2UsIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmNvbnN0IG9yaWdpbmFsUGF0aG5hbWUgPSBcIi9hcGkvY2hhdC9yb3V0ZVwiO1xuZnVuY3Rpb24gcGF0Y2hGZXRjaCgpIHtcbiAgICByZXR1cm4gX3BhdGNoRmV0Y2goe1xuICAgICAgICBzZXJ2ZXJIb29rcyxcbiAgICAgICAgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZVxuICAgIH0pO1xufVxuZXhwb3J0IHsgcm91dGVNb2R1bGUsIHJlcXVlc3RBc3luY1N0b3JhZ2UsIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzLCBvcmlnaW5hbFBhdGhuYW1lLCBwYXRjaEZldGNoLCAgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXBwLXJvdXRlLmpzLm1hcCJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fchat%2Froute&page=%2Fapi%2Fchat%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fchat%2Froute.ts&appDir=%2FUsers%2Fshivaylamba%2FDesktop%2Fcb-projects%2Flivestream-new%2Fchat-with-pdf%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fshivaylamba%2FDesktop%2Fcb-projects%2Flivestream-new%2Fchat-with-pdf&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./src/app/api/chat/route.ts":
/*!***********************************!*\
  !*** ./src/app/api/chat/route.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var _langchain_community_vectorstores_couchbase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @langchain/community/vectorstores/couchbase */ \"(rsc)/./node_modules/@langchain/community/vectorstores/couchbase.js\");\n/* harmony import */ var _langchain_openai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @langchain/openai */ \"(rsc)/./node_modules/@langchain/openai/index.js\");\n/* harmony import */ var _lib_couchbase_connection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/lib/couchbase-connection */ \"(rsc)/./src/lib/couchbase-connection.ts\");\n/* harmony import */ var ai__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ai */ \"(rsc)/./node_modules/ai/dist/index.mjs\");\n/* harmony import */ var _langchain_core_messages__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @langchain/core/messages */ \"(rsc)/./node_modules/@langchain/core/messages.js\");\n/* harmony import */ var _langchain_core_runnables__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @langchain/core/runnables */ \"(rsc)/./node_modules/@langchain/core/runnables.js\");\n/* harmony import */ var langchain_chains_history_aware_retriever__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! langchain/chains/history_aware_retriever */ \"(rsc)/./node_modules/langchain/chains/history_aware_retriever.js\");\n/* harmony import */ var _langchain_core_prompts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @langchain/core/prompts */ \"(rsc)/./node_modules/@langchain/core/prompts.js\");\n/* harmony import */ var langchain_chains_combine_documents__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! langchain/chains/combine_documents */ \"(rsc)/./node_modules/langchain/chains/combine_documents.js\");\n/* harmony import */ var langchain_chains_retrieval__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! langchain/chains/retrieval */ \"(rsc)/./node_modules/langchain/chains/retrieval.js\");\n/* harmony import */ var langchain_output_parsers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! langchain/output_parsers */ \"(rsc)/./node_modules/langchain/output_parsers.js\");\n\n\n\n\n\n\n\n\n\n\n\nconst formatVercelMessages = (message)=>{\n    if (message.role === \"user\") {\n        return new _langchain_core_messages__WEBPACK_IMPORTED_MODULE_3__.HumanMessage(message.content);\n    } else if (message.role === \"assistant\") {\n        return new _langchain_core_messages__WEBPACK_IMPORTED_MODULE_3__.AIMessage(message.content);\n    } else {\n        console.warn(`Unknown message type passed: \"${message.role}\". Falling back to generic message type.`);\n        return new _langchain_core_messages__WEBPACK_IMPORTED_MODULE_3__.ChatMessage({\n            content: message.content,\n            role: message.role\n        });\n    }\n};\nasync function POST(request) {\n    const body = await request.json();\n    const messages = body.messages ?? [];\n    if (!messages.length) {\n        throw new Error(\"No messages provided.\");\n    }\n    const formattedPreviousMessages = messages.slice(0, -1).map(formatVercelMessages);\n    const currentMessageContent = messages[messages.length - 1].content;\n    try {\n        const model = new _langchain_openai__WEBPACK_IMPORTED_MODULE_1__.ChatOpenAI({});\n        const embeddings = new _langchain_openai__WEBPACK_IMPORTED_MODULE_1__.OpenAIEmbeddings({\n            openAIApiKey: process.env.OPENAI_API_KEY\n        });\n        const historyAwarePrompt = _langchain_core_prompts__WEBPACK_IMPORTED_MODULE_6__.ChatPromptTemplate.fromMessages([\n            new _langchain_core_prompts__WEBPACK_IMPORTED_MODULE_6__.MessagesPlaceholder(\"chat_history\"),\n            [\n                \"user\",\n                \"{input}\"\n            ],\n            [\n                \"user\",\n                \"Given the above conversation, generate a concise vector store search query to look up in order to get information relevant to the conversation.\"\n            ]\n        ]);\n        const ANSWER_SYSTEM_TEMPLATE = `You are a helpful AI assistant. Use the following pieces of context to answer the question at the end.\n      If you don't know the answer, just say you don't know. DO NOT try to make up an answer.\n      If the question is not related to the context, politely respond that you are tuned to only answer questions that are related to the context.\n      \n      <context>\n      {context}\n      </context>\n      \n      Please return your answer in markdown with clear headings and lists.`;\n        const answerPrompt = _langchain_core_prompts__WEBPACK_IMPORTED_MODULE_6__.ChatPromptTemplate.fromMessages([\n            [\n                \"system\",\n                ANSWER_SYSTEM_TEMPLATE\n            ],\n            new _langchain_core_prompts__WEBPACK_IMPORTED_MODULE_6__.MessagesPlaceholder(\"chat_history\"),\n            [\n                \"user\",\n                \"{input}\"\n            ]\n        ]);\n        const bucketName = process.env.DB_BUCKET || \"\";\n        const scopeName = process.env.DB_SCOPE || \"\";\n        const collectionName = process.env.DB_COLLECTION || \"\";\n        const indexName = process.env.INDEX_NAME || \"\";\n        const textKey = \"text\";\n        const embeddingKey = \"embedding\";\n        const scopedIndex = true;\n        const cluster = await (0,_lib_couchbase_connection__WEBPACK_IMPORTED_MODULE_2__.createCouchbaseCluster)();\n        const couchbaseConfig = {\n            cluster,\n            bucketName,\n            scopeName,\n            collectionName,\n            indexName,\n            textKey,\n            embeddingKey,\n            scopedIndex\n        };\n        const couchbaseVectorStore = await _langchain_community_vectorstores_couchbase__WEBPACK_IMPORTED_MODULE_0__.CouchbaseVectorStore.initialize(embeddings, couchbaseConfig);\n        let resolveWithDocuments;\n        const documentPromise = new Promise((resolve)=>{\n            resolveWithDocuments = resolve;\n        });\n        const retriever = couchbaseVectorStore.asRetriever({\n            callbacks: [\n                {\n                    handleRetrieverEnd (documents) {\n                        // Extract retrieved source documents so that they can be displayed as sources\n                        // on the frontend.\n                        resolveWithDocuments(documents);\n                    }\n                }\n            ]\n        });\n        const historyAwareRetrieverChain = await (0,langchain_chains_history_aware_retriever__WEBPACK_IMPORTED_MODULE_5__.createHistoryAwareRetriever)({\n            llm: model,\n            retriever,\n            rephrasePrompt: historyAwarePrompt\n        });\n        // Create a chain that answers questions using retrieved relevant documents as context.\n        const documentChain = await (0,langchain_chains_combine_documents__WEBPACK_IMPORTED_MODULE_7__.createStuffDocumentsChain)({\n            llm: model,\n            prompt: answerPrompt\n        });\n        // Create a chain that combines the above retriever and question answering chains.\n        const conversationalRetrievalChain = await (0,langchain_chains_retrieval__WEBPACK_IMPORTED_MODULE_8__.createRetrievalChain)({\n            retriever: historyAwareRetrieverChain,\n            combineDocsChain: documentChain\n        });\n        // \"Pick\" the answer from the retrieval chain output object and stream it as bytes.\n        const outputChain = _langchain_core_runnables__WEBPACK_IMPORTED_MODULE_4__.RunnableSequence.from([\n            conversationalRetrievalChain,\n            new _langchain_core_runnables__WEBPACK_IMPORTED_MODULE_4__.RunnablePick({\n                keys: \"answer\"\n            }),\n            new langchain_output_parsers__WEBPACK_IMPORTED_MODULE_9__.HttpResponseOutputParser({\n                contentType: \"text/plain\"\n            })\n        ]);\n        const stream = await outputChain.stream({\n            chat_history: formattedPreviousMessages,\n            input: currentMessageContent\n        });\n        const documents = await documentPromise;\n        const serializedSources = Buffer.from(JSON.stringify(documents.map((doc)=>{\n            return {\n                pageContent: doc.pageContent.slice(0, 50) + \"...\",\n                metadata: doc.metadata\n            };\n        }))).toString(\"base64\");\n        return new ai__WEBPACK_IMPORTED_MODULE_10__.StreamingTextResponse(stream, {\n            headers: {\n                \"x-message-index\": (formattedPreviousMessages.length + 1).toString(),\n                \"x-sources\": serializedSources\n            }\n        });\n    } catch (err) {\n        console.log(\"Error Received \", err);\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS9jaGF0L3JvdXRlLnRzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUdxRDtBQUNZO0FBQ0c7QUFDSztBQUNPO0FBSTdDO0FBQ29EO0FBQ0w7QUFDSDtBQUNiO0FBQ0U7QUFHcEUsTUFBTWdCLHVCQUF1QixDQUFDQztJQUM1QixJQUFJQSxRQUFRQyxJQUFJLEtBQUssUUFBUTtRQUMzQixPQUFPLElBQUliLGtFQUFZQSxDQUFDWSxRQUFRRSxPQUFPO0lBQ3pDLE9BQU8sSUFBSUYsUUFBUUMsSUFBSSxLQUFLLGFBQWE7UUFDdkMsT0FBTyxJQUFJWiwrREFBU0EsQ0FBQ1csUUFBUUUsT0FBTztJQUN0QyxPQUFPO1FBQ0xDLFFBQVFDLElBQUksQ0FDVixDQUFDLDhCQUE4QixFQUFFSixRQUFRQyxJQUFJLENBQUMsd0NBQXdDLENBQUM7UUFFekYsT0FBTyxJQUFJWCxpRUFBV0EsQ0FBQztZQUFFWSxTQUFTRixRQUFRRSxPQUFPO1lBQUVELE1BQU1ELFFBQVFDLElBQUk7UUFBQztJQUN4RTtBQUNGO0FBRU8sZUFBZUksS0FBS0MsT0FBZ0I7SUFDekMsTUFBTUMsT0FBTyxNQUFNRCxRQUFRRSxJQUFJO0lBQy9CLE1BQU1DLFdBQVdGLEtBQUtFLFFBQVEsSUFBSSxFQUFFO0lBQ3BDLElBQUksQ0FBQ0EsU0FBU0MsTUFBTSxFQUFFO1FBQ3BCLE1BQU0sSUFBSUMsTUFBTTtJQUNsQjtJQUNBLE1BQU1DLDRCQUE0QkgsU0FDL0JJLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FDVkMsR0FBRyxDQUFDZjtJQUVQLE1BQU1nQix3QkFBd0JOLFFBQVEsQ0FBQ0EsU0FBU0MsTUFBTSxHQUFHLEVBQUUsQ0FBQ1IsT0FBTztJQUNuRSxJQUFJO1FBQ0YsTUFBTWMsUUFBUSxJQUFJaEMseURBQVVBLENBQUMsQ0FBQztRQUM5QixNQUFNaUMsYUFBYSxJQUFJaEMsK0RBQWdCQSxDQUFDO1lBQ3RDaUMsY0FBY0MsUUFBUUMsR0FBRyxDQUFDQyxjQUFjO1FBQzFDO1FBRUEsTUFBTUMscUJBQXFCNUIsdUVBQWtCQSxDQUFDNkIsWUFBWSxDQUFDO1lBQ3pELElBQUk1Qix3RUFBbUJBLENBQUM7WUFDeEI7Z0JBQUM7Z0JBQVE7YUFBVTtZQUNuQjtnQkFDRTtnQkFDQTthQUNEO1NBQ0Y7UUFFRCxNQUFNNkIseUJBQXlCLENBQUM7Ozs7Ozs7OzBFQVFzQyxDQUFDO1FBRXZFLE1BQU1DLGVBQWUvQix1RUFBa0JBLENBQUM2QixZQUFZLENBQUM7WUFDbkQ7Z0JBQUM7Z0JBQVVDO2FBQXVCO1lBQ2xDLElBQUk3Qix3RUFBbUJBLENBQUM7WUFDeEI7Z0JBQUM7Z0JBQVE7YUFBVTtTQUNwQjtRQUVELE1BQU0rQixhQUFhUCxRQUFRQyxHQUFHLENBQUNPLFNBQVMsSUFBSTtRQUM1QyxNQUFNQyxZQUFZVCxRQUFRQyxHQUFHLENBQUNTLFFBQVEsSUFBSTtRQUMxQyxNQUFNQyxpQkFBaUJYLFFBQVFDLEdBQUcsQ0FBQ1csYUFBYSxJQUFJO1FBQ3BELE1BQU1DLFlBQVliLFFBQVFDLEdBQUcsQ0FBQ2EsVUFBVSxJQUFJO1FBQzVDLE1BQU1DLFVBQVU7UUFDaEIsTUFBTUMsZUFBZTtRQUNyQixNQUFNQyxjQUFjO1FBRXBCLE1BQU1DLFVBQVUsTUFBTW5ELGlGQUFzQkE7UUFDNUMsTUFBTW9ELGtCQUE0QztZQUNoREQ7WUFDQVg7WUFDQUU7WUFDQUU7WUFDQUU7WUFDQUU7WUFDQUM7WUFDQUM7UUFDRjtRQUNBLE1BQU1HLHVCQUF1QixNQUFNeEQsNkZBQW9CQSxDQUFDeUQsVUFBVSxDQUNoRXZCLFlBQ0FxQjtRQUdGLElBQUlHO1FBQ0osTUFBTUMsa0JBQWtCLElBQUlDLFFBQW9CLENBQUNDO1lBQy9DSCx1QkFBdUJHO1FBQ3pCO1FBRUEsTUFBTUMsWUFBWU4scUJBQXFCTyxXQUFXLENBQUM7WUFDakRDLFdBQVc7Z0JBQ1Q7b0JBQ0VDLG9CQUFtQkMsU0FBUzt3QkFDMUIsOEVBQThFO3dCQUM5RSxtQkFBbUI7d0JBQ25CUixxQkFBcUJRO29CQUN2QjtnQkFDRjthQUNEO1FBQ0g7UUFHQSxNQUFNQyw2QkFBNkIsTUFBTXpELHFHQUEyQkEsQ0FBQztZQUNuRTBELEtBQUtuQztZQUNMNkI7WUFDQU8sZ0JBQWdCOUI7UUFDbEI7UUFFQSx1RkFBdUY7UUFDdkYsTUFBTStCLGdCQUFnQixNQUFNekQsNkZBQXlCQSxDQUFDO1lBQ3BEdUQsS0FBS25DO1lBQ0xzQyxRQUFRN0I7UUFDVjtRQUVBLGtGQUFrRjtRQUNsRixNQUFNOEIsK0JBQStCLE1BQU0xRCxnRkFBb0JBLENBQUM7WUFDOURnRCxXQUFXSztZQUNYTSxrQkFBa0JIO1FBQ3BCO1FBRUEsbUZBQW1GO1FBQ25GLE1BQU1JLGNBQWNsRSx1RUFBZ0JBLENBQUNtRSxJQUFJLENBQUM7WUFDeENIO1lBQ0EsSUFBSS9ELG1FQUFZQSxDQUFDO2dCQUFFbUUsTUFBTTtZQUFTO1lBQ2xDLElBQUk3RCw4RUFBd0JBLENBQUM7Z0JBQUU4RCxhQUFhO1lBQWE7U0FDMUQ7UUFFRCxNQUFNQyxTQUFTLE1BQU1KLFlBQVlJLE1BQU0sQ0FBQztZQUN0Q0MsY0FBY2xEO1lBQ2RtRCxPQUFPaEQ7UUFDVDtRQUVBLE1BQU1rQyxZQUFZLE1BQU1QO1FBQ3hCLE1BQU1zQixvQkFBb0JDLE9BQU9QLElBQUksQ0FDbkNRLEtBQUtDLFNBQVMsQ0FDWmxCLFVBQVVuQyxHQUFHLENBQUMsQ0FBQ3NEO1lBQ2IsT0FBTztnQkFDTEMsYUFBYUQsSUFBSUMsV0FBVyxDQUFDeEQsS0FBSyxDQUFDLEdBQUcsTUFBTTtnQkFDNUN5RCxVQUFVRixJQUFJRSxRQUFRO1lBQ3hCO1FBQ0YsS0FFRkMsUUFBUSxDQUFDO1FBRVgsT0FBTyxJQUFJcEYsc0RBQXFCQSxDQUFDMEUsUUFBUTtZQUN2Q1csU0FBUztnQkFDUCxtQkFBbUIsQ0FBQzVELDBCQUEwQkYsTUFBTSxHQUFHLEdBQUc2RCxRQUFRO2dCQUNsRSxhQUFhUDtZQUNmO1FBQ0Y7SUFFRixFQUFFLE9BQU9TLEtBQUs7UUFDWnRFLFFBQVF1RSxHQUFHLENBQUMsbUJBQW1CRDtJQUNqQztBQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2hhdC13aXRoLXBkZi8uL3NyYy9hcHAvYXBpL2NoYXQvcm91dGUudHM/NDZiNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBDb3VjaGJhc2VWZWN0b3JTdG9yZSxcbiAgQ291Y2hiYXNlVmVjdG9yU3RvcmVBcmdzLFxufSBmcm9tIFwiQGxhbmdjaGFpbi9jb21tdW5pdHkvdmVjdG9yc3RvcmVzL2NvdWNoYmFzZVwiO1xuaW1wb3J0IHsgQ2hhdE9wZW5BSSwgT3BlbkFJRW1iZWRkaW5ncyB9IGZyb20gXCJAbGFuZ2NoYWluL29wZW5haVwiO1xuaW1wb3J0IHsgY3JlYXRlQ291Y2hiYXNlQ2x1c3RlciB9IGZyb20gXCJAL2xpYi9jb3VjaGJhc2UtY29ubmVjdGlvblwiO1xuaW1wb3J0IHsgTWVzc2FnZSBhcyBWZXJjZWxDaGF0TWVzc2FnZSwgU3RyZWFtaW5nVGV4dFJlc3BvbnNlIH0gZnJvbSBcImFpXCI7XG5pbXBvcnQgeyBIdW1hbk1lc3NhZ2UsIEFJTWVzc2FnZSwgQ2hhdE1lc3NhZ2UgfSBmcm9tIFwiQGxhbmdjaGFpbi9jb3JlL21lc3NhZ2VzXCI7XG5pbXBvcnQge1xuICBSdW5uYWJsZVNlcXVlbmNlLFxuICBSdW5uYWJsZVBpY2tcbn0gZnJvbSBcIkBsYW5nY2hhaW4vY29yZS9ydW5uYWJsZXNcIjtcbmltcG9ydCB7IGNyZWF0ZUhpc3RvcnlBd2FyZVJldHJpZXZlciB9IGZyb20gXCJsYW5nY2hhaW4vY2hhaW5zL2hpc3RvcnlfYXdhcmVfcmV0cmlldmVyXCI7XG5pbXBvcnQgeyBDaGF0UHJvbXB0VGVtcGxhdGUsIE1lc3NhZ2VzUGxhY2Vob2xkZXIgfSBmcm9tIFwiQGxhbmdjaGFpbi9jb3JlL3Byb21wdHNcIjtcbmltcG9ydCB7IGNyZWF0ZVN0dWZmRG9jdW1lbnRzQ2hhaW4gfSBmcm9tIFwibGFuZ2NoYWluL2NoYWlucy9jb21iaW5lX2RvY3VtZW50c1wiO1xuaW1wb3J0IHsgY3JlYXRlUmV0cmlldmFsQ2hhaW4gfSBmcm9tIFwibGFuZ2NoYWluL2NoYWlucy9yZXRyaWV2YWxcIjtcbmltcG9ydCB7IEh0dHBSZXNwb25zZU91dHB1dFBhcnNlciB9IGZyb20gXCJsYW5nY2hhaW4vb3V0cHV0X3BhcnNlcnNcIjtcbmltcG9ydCB7IERvY3VtZW50IH0gZnJvbSAnQGxhbmdjaGFpbi9jb3JlL2RvY3VtZW50cyc7XG5cbmNvbnN0IGZvcm1hdFZlcmNlbE1lc3NhZ2VzID0gKG1lc3NhZ2U6IFZlcmNlbENoYXRNZXNzYWdlKSA9PiB7XG4gIGlmIChtZXNzYWdlLnJvbGUgPT09IFwidXNlclwiKSB7XG4gICAgcmV0dXJuIG5ldyBIdW1hbk1lc3NhZ2UobWVzc2FnZS5jb250ZW50KTtcbiAgfSBlbHNlIGlmIChtZXNzYWdlLnJvbGUgPT09IFwiYXNzaXN0YW50XCIpIHtcbiAgICByZXR1cm4gbmV3IEFJTWVzc2FnZShtZXNzYWdlLmNvbnRlbnQpO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUud2FybihcbiAgICAgIGBVbmtub3duIG1lc3NhZ2UgdHlwZSBwYXNzZWQ6IFwiJHttZXNzYWdlLnJvbGV9XCIuIEZhbGxpbmcgYmFjayB0byBnZW5lcmljIG1lc3NhZ2UgdHlwZS5gXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IENoYXRNZXNzYWdlKHsgY29udGVudDogbWVzc2FnZS5jb250ZW50LCByb2xlOiBtZXNzYWdlLnJvbGUgfSk7XG4gIH1cbn07XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBQT1NUKHJlcXVlc3Q6IFJlcXVlc3QpIHtcbiAgY29uc3QgYm9keSA9IGF3YWl0IHJlcXVlc3QuanNvbigpO1xuICBjb25zdCBtZXNzYWdlcyA9IGJvZHkubWVzc2FnZXMgPz8gW107XG4gIGlmICghbWVzc2FnZXMubGVuZ3RoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gbWVzc2FnZXMgcHJvdmlkZWQuXCIpO1xuICB9XG4gIGNvbnN0IGZvcm1hdHRlZFByZXZpb3VzTWVzc2FnZXMgPSBtZXNzYWdlc1xuICAgIC5zbGljZSgwLCAtMSlcbiAgICAubWFwKGZvcm1hdFZlcmNlbE1lc3NhZ2VzKTtcblxuICBjb25zdCBjdXJyZW50TWVzc2FnZUNvbnRlbnQgPSBtZXNzYWdlc1ttZXNzYWdlcy5sZW5ndGggLSAxXS5jb250ZW50O1xuICB0cnkge1xuICAgIGNvbnN0IG1vZGVsID0gbmV3IENoYXRPcGVuQUkoe30pO1xuICAgIGNvbnN0IGVtYmVkZGluZ3MgPSBuZXcgT3BlbkFJRW1iZWRkaW5ncyh7XG4gICAgICBvcGVuQUlBcGlLZXk6IHByb2Nlc3MuZW52Lk9QRU5BSV9BUElfS0VZLFxuICAgIH0pO1xuXG4gICAgY29uc3QgaGlzdG9yeUF3YXJlUHJvbXB0ID0gQ2hhdFByb21wdFRlbXBsYXRlLmZyb21NZXNzYWdlcyhbXG4gICAgICBuZXcgTWVzc2FnZXNQbGFjZWhvbGRlcihcImNoYXRfaGlzdG9yeVwiKSxcbiAgICAgIFtcInVzZXJcIiwgXCJ7aW5wdXR9XCJdLFxuICAgICAgW1xuICAgICAgICBcInVzZXJcIixcbiAgICAgICAgXCJHaXZlbiB0aGUgYWJvdmUgY29udmVyc2F0aW9uLCBnZW5lcmF0ZSBhIGNvbmNpc2UgdmVjdG9yIHN0b3JlIHNlYXJjaCBxdWVyeSB0byBsb29rIHVwIGluIG9yZGVyIHRvIGdldCBpbmZvcm1hdGlvbiByZWxldmFudCB0byB0aGUgY29udmVyc2F0aW9uLlwiLFxuICAgICAgXSxcbiAgICBdKTtcblxuICAgIGNvbnN0IEFOU1dFUl9TWVNURU1fVEVNUExBVEUgPSBgWW91IGFyZSBhIGhlbHBmdWwgQUkgYXNzaXN0YW50LiBVc2UgdGhlIGZvbGxvd2luZyBwaWVjZXMgb2YgY29udGV4dCB0byBhbnN3ZXIgdGhlIHF1ZXN0aW9uIGF0IHRoZSBlbmQuXG4gICAgICBJZiB5b3UgZG9uJ3Qga25vdyB0aGUgYW5zd2VyLCBqdXN0IHNheSB5b3UgZG9uJ3Qga25vdy4gRE8gTk9UIHRyeSB0byBtYWtlIHVwIGFuIGFuc3dlci5cbiAgICAgIElmIHRoZSBxdWVzdGlvbiBpcyBub3QgcmVsYXRlZCB0byB0aGUgY29udGV4dCwgcG9saXRlbHkgcmVzcG9uZCB0aGF0IHlvdSBhcmUgdHVuZWQgdG8gb25seSBhbnN3ZXIgcXVlc3Rpb25zIHRoYXQgYXJlIHJlbGF0ZWQgdG8gdGhlIGNvbnRleHQuXG4gICAgICBcbiAgICAgIDxjb250ZXh0PlxuICAgICAge2NvbnRleHR9XG4gICAgICA8L2NvbnRleHQ+XG4gICAgICBcbiAgICAgIFBsZWFzZSByZXR1cm4geW91ciBhbnN3ZXIgaW4gbWFya2Rvd24gd2l0aCBjbGVhciBoZWFkaW5ncyBhbmQgbGlzdHMuYDtcblxuICAgIGNvbnN0IGFuc3dlclByb21wdCA9IENoYXRQcm9tcHRUZW1wbGF0ZS5mcm9tTWVzc2FnZXMoW1xuICAgICAgW1wic3lzdGVtXCIsIEFOU1dFUl9TWVNURU1fVEVNUExBVEVdLFxuICAgICAgbmV3IE1lc3NhZ2VzUGxhY2Vob2xkZXIoXCJjaGF0X2hpc3RvcnlcIiksXG4gICAgICBbXCJ1c2VyXCIsIFwie2lucHV0fVwiXSxcbiAgICBdKTtcblxuICAgIGNvbnN0IGJ1Y2tldE5hbWUgPSBwcm9jZXNzLmVudi5EQl9CVUNLRVQgfHwgXCJcIjtcbiAgICBjb25zdCBzY29wZU5hbWUgPSBwcm9jZXNzLmVudi5EQl9TQ09QRSB8fCBcIlwiO1xuICAgIGNvbnN0IGNvbGxlY3Rpb25OYW1lID0gcHJvY2Vzcy5lbnYuREJfQ09MTEVDVElPTiB8fCBcIlwiO1xuICAgIGNvbnN0IGluZGV4TmFtZSA9IHByb2Nlc3MuZW52LklOREVYX05BTUUgfHwgXCJcIjtcbiAgICBjb25zdCB0ZXh0S2V5ID0gXCJ0ZXh0XCI7XG4gICAgY29uc3QgZW1iZWRkaW5nS2V5ID0gXCJlbWJlZGRpbmdcIjtcbiAgICBjb25zdCBzY29wZWRJbmRleCA9IHRydWU7XG5cbiAgICBjb25zdCBjbHVzdGVyID0gYXdhaXQgY3JlYXRlQ291Y2hiYXNlQ2x1c3RlcigpO1xuICAgIGNvbnN0IGNvdWNoYmFzZUNvbmZpZzogQ291Y2hiYXNlVmVjdG9yU3RvcmVBcmdzID0ge1xuICAgICAgY2x1c3RlcixcbiAgICAgIGJ1Y2tldE5hbWUsXG4gICAgICBzY29wZU5hbWUsXG4gICAgICBjb2xsZWN0aW9uTmFtZSxcbiAgICAgIGluZGV4TmFtZSxcbiAgICAgIHRleHRLZXksXG4gICAgICBlbWJlZGRpbmdLZXksXG4gICAgICBzY29wZWRJbmRleCxcbiAgICB9O1xuICAgIGNvbnN0IGNvdWNoYmFzZVZlY3RvclN0b3JlID0gYXdhaXQgQ291Y2hiYXNlVmVjdG9yU3RvcmUuaW5pdGlhbGl6ZShcbiAgICAgIGVtYmVkZGluZ3MsXG4gICAgICBjb3VjaGJhc2VDb25maWdcbiAgICApO1xuXG4gICAgbGV0IHJlc29sdmVXaXRoRG9jdW1lbnRzOiAodmFsdWU6IERvY3VtZW50W10pID0+IHZvaWQ7XG4gICAgY29uc3QgZG9jdW1lbnRQcm9taXNlID0gbmV3IFByb21pc2U8RG9jdW1lbnRbXT4oKHJlc29sdmUpID0+IHtcbiAgICAgIHJlc29sdmVXaXRoRG9jdW1lbnRzID0gcmVzb2x2ZTtcbiAgICB9KTtcblxuICAgIGNvbnN0IHJldHJpZXZlciA9IGNvdWNoYmFzZVZlY3RvclN0b3JlLmFzUmV0cmlldmVyKHtcbiAgICAgIGNhbGxiYWNrczogW1xuICAgICAgICB7XG4gICAgICAgICAgaGFuZGxlUmV0cmlldmVyRW5kKGRvY3VtZW50cykge1xuICAgICAgICAgICAgLy8gRXh0cmFjdCByZXRyaWV2ZWQgc291cmNlIGRvY3VtZW50cyBzbyB0aGF0IHRoZXkgY2FuIGJlIGRpc3BsYXllZCBhcyBzb3VyY2VzXG4gICAgICAgICAgICAvLyBvbiB0aGUgZnJvbnRlbmQuXG4gICAgICAgICAgICByZXNvbHZlV2l0aERvY3VtZW50cyhkb2N1bWVudHMpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICBdLFxuICAgIH1cbiAgICApO1xuXG4gICAgY29uc3QgaGlzdG9yeUF3YXJlUmV0cmlldmVyQ2hhaW4gPSBhd2FpdCBjcmVhdGVIaXN0b3J5QXdhcmVSZXRyaWV2ZXIoe1xuICAgICAgbGxtOiBtb2RlbCxcbiAgICAgIHJldHJpZXZlcixcbiAgICAgIHJlcGhyYXNlUHJvbXB0OiBoaXN0b3J5QXdhcmVQcm9tcHQsXG4gICAgfSk7XG5cbiAgICAvLyBDcmVhdGUgYSBjaGFpbiB0aGF0IGFuc3dlcnMgcXVlc3Rpb25zIHVzaW5nIHJldHJpZXZlZCByZWxldmFudCBkb2N1bWVudHMgYXMgY29udGV4dC5cbiAgICBjb25zdCBkb2N1bWVudENoYWluID0gYXdhaXQgY3JlYXRlU3R1ZmZEb2N1bWVudHNDaGFpbih7XG4gICAgICBsbG06IG1vZGVsLFxuICAgICAgcHJvbXB0OiBhbnN3ZXJQcm9tcHQsXG4gICAgfSk7XG5cbiAgICAvLyBDcmVhdGUgYSBjaGFpbiB0aGF0IGNvbWJpbmVzIHRoZSBhYm92ZSByZXRyaWV2ZXIgYW5kIHF1ZXN0aW9uIGFuc3dlcmluZyBjaGFpbnMuXG4gICAgY29uc3QgY29udmVyc2F0aW9uYWxSZXRyaWV2YWxDaGFpbiA9IGF3YWl0IGNyZWF0ZVJldHJpZXZhbENoYWluKHtcbiAgICAgIHJldHJpZXZlcjogaGlzdG9yeUF3YXJlUmV0cmlldmVyQ2hhaW4sXG4gICAgICBjb21iaW5lRG9jc0NoYWluOiBkb2N1bWVudENoYWluLFxuICAgIH0pO1xuXG4gICAgLy8gXCJQaWNrXCIgdGhlIGFuc3dlciBmcm9tIHRoZSByZXRyaWV2YWwgY2hhaW4gb3V0cHV0IG9iamVjdCBhbmQgc3RyZWFtIGl0IGFzIGJ5dGVzLlxuICAgIGNvbnN0IG91dHB1dENoYWluID0gUnVubmFibGVTZXF1ZW5jZS5mcm9tKFtcbiAgICAgIGNvbnZlcnNhdGlvbmFsUmV0cmlldmFsQ2hhaW4sXG4gICAgICBuZXcgUnVubmFibGVQaWNrKHsga2V5czogXCJhbnN3ZXJcIiB9KSxcbiAgICAgIG5ldyBIdHRwUmVzcG9uc2VPdXRwdXRQYXJzZXIoeyBjb250ZW50VHlwZTogXCJ0ZXh0L3BsYWluXCIgfSksXG4gICAgXSk7XG5cbiAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBvdXRwdXRDaGFpbi5zdHJlYW0oe1xuICAgICAgY2hhdF9oaXN0b3J5OiBmb3JtYXR0ZWRQcmV2aW91c01lc3NhZ2VzLFxuICAgICAgaW5wdXQ6IGN1cnJlbnRNZXNzYWdlQ29udGVudCxcbiAgICB9KTtcblxuICAgIGNvbnN0IGRvY3VtZW50cyA9IGF3YWl0IGRvY3VtZW50UHJvbWlzZTtcbiAgICBjb25zdCBzZXJpYWxpemVkU291cmNlcyA9IEJ1ZmZlci5mcm9tKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoXG4gICAgICAgIGRvY3VtZW50cy5tYXAoKGRvYykgPT4ge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBwYWdlQ29udGVudDogZG9jLnBhZ2VDb250ZW50LnNsaWNlKDAsIDUwKSArICcuLi4nLFxuICAgICAgICAgICAgbWV0YWRhdGE6IGRvYy5tZXRhZGF0YSxcbiAgICAgICAgICB9O1xuICAgICAgICB9KSxcbiAgICAgICksXG4gICAgKS50b1N0cmluZygnYmFzZTY0Jyk7XG5cbiAgICByZXR1cm4gbmV3IFN0cmVhbWluZ1RleHRSZXNwb25zZShzdHJlYW0sIHtcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ3gtbWVzc2FnZS1pbmRleCc6IChmb3JtYXR0ZWRQcmV2aW91c01lc3NhZ2VzLmxlbmd0aCArIDEpLnRvU3RyaW5nKCksXG4gICAgICAgICd4LXNvdXJjZXMnOiBzZXJpYWxpemVkU291cmNlcyxcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5sb2coXCJFcnJvciBSZWNlaXZlZCBcIiwgZXJyKTtcbiAgfVxufVxuIl0sIm5hbWVzIjpbIkNvdWNoYmFzZVZlY3RvclN0b3JlIiwiQ2hhdE9wZW5BSSIsIk9wZW5BSUVtYmVkZGluZ3MiLCJjcmVhdGVDb3VjaGJhc2VDbHVzdGVyIiwiU3RyZWFtaW5nVGV4dFJlc3BvbnNlIiwiSHVtYW5NZXNzYWdlIiwiQUlNZXNzYWdlIiwiQ2hhdE1lc3NhZ2UiLCJSdW5uYWJsZVNlcXVlbmNlIiwiUnVubmFibGVQaWNrIiwiY3JlYXRlSGlzdG9yeUF3YXJlUmV0cmlldmVyIiwiQ2hhdFByb21wdFRlbXBsYXRlIiwiTWVzc2FnZXNQbGFjZWhvbGRlciIsImNyZWF0ZVN0dWZmRG9jdW1lbnRzQ2hhaW4iLCJjcmVhdGVSZXRyaWV2YWxDaGFpbiIsIkh0dHBSZXNwb25zZU91dHB1dFBhcnNlciIsImZvcm1hdFZlcmNlbE1lc3NhZ2VzIiwibWVzc2FnZSIsInJvbGUiLCJjb250ZW50IiwiY29uc29sZSIsIndhcm4iLCJQT1NUIiwicmVxdWVzdCIsImJvZHkiLCJqc29uIiwibWVzc2FnZXMiLCJsZW5ndGgiLCJFcnJvciIsImZvcm1hdHRlZFByZXZpb3VzTWVzc2FnZXMiLCJzbGljZSIsIm1hcCIsImN1cnJlbnRNZXNzYWdlQ29udGVudCIsIm1vZGVsIiwiZW1iZWRkaW5ncyIsIm9wZW5BSUFwaUtleSIsInByb2Nlc3MiLCJlbnYiLCJPUEVOQUlfQVBJX0tFWSIsImhpc3RvcnlBd2FyZVByb21wdCIsImZyb21NZXNzYWdlcyIsIkFOU1dFUl9TWVNURU1fVEVNUExBVEUiLCJhbnN3ZXJQcm9tcHQiLCJidWNrZXROYW1lIiwiREJfQlVDS0VUIiwic2NvcGVOYW1lIiwiREJfU0NPUEUiLCJjb2xsZWN0aW9uTmFtZSIsIkRCX0NPTExFQ1RJT04iLCJpbmRleE5hbWUiLCJJTkRFWF9OQU1FIiwidGV4dEtleSIsImVtYmVkZGluZ0tleSIsInNjb3BlZEluZGV4IiwiY2x1c3RlciIsImNvdWNoYmFzZUNvbmZpZyIsImNvdWNoYmFzZVZlY3RvclN0b3JlIiwiaW5pdGlhbGl6ZSIsInJlc29sdmVXaXRoRG9jdW1lbnRzIiwiZG9jdW1lbnRQcm9taXNlIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZXRyaWV2ZXIiLCJhc1JldHJpZXZlciIsImNhbGxiYWNrcyIsImhhbmRsZVJldHJpZXZlckVuZCIsImRvY3VtZW50cyIsImhpc3RvcnlBd2FyZVJldHJpZXZlckNoYWluIiwibGxtIiwicmVwaHJhc2VQcm9tcHQiLCJkb2N1bWVudENoYWluIiwicHJvbXB0IiwiY29udmVyc2F0aW9uYWxSZXRyaWV2YWxDaGFpbiIsImNvbWJpbmVEb2NzQ2hhaW4iLCJvdXRwdXRDaGFpbiIsImZyb20iLCJrZXlzIiwiY29udGVudFR5cGUiLCJzdHJlYW0iLCJjaGF0X2hpc3RvcnkiLCJpbnB1dCIsInNlcmlhbGl6ZWRTb3VyY2VzIiwiQnVmZmVyIiwiSlNPTiIsInN0cmluZ2lmeSIsImRvYyIsInBhZ2VDb250ZW50IiwibWV0YWRhdGEiLCJ0b1N0cmluZyIsImhlYWRlcnMiLCJlcnIiLCJsb2ciXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/chat/route.ts\n");

/***/ }),

/***/ "(rsc)/./src/lib/couchbase-connection.ts":
/*!*****************************************!*\
  !*** ./src/lib/couchbase-connection.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   createCouchbaseCluster: () => (/* binding */ createCouchbaseCluster)\n/* harmony export */ });\n/* harmony import */ var couchbase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! couchbase */ \"(rsc)/./node_modules/couchbase/dist/couchbase.js\");\n/* harmony import */ var couchbase__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(couchbase__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function createCouchbaseCluster() {\n    const connectionString = process.env.DB_CONN_STR;\n    const databaseUsername = process.env.DB_USERNAME;\n    const databasePassword = process.env.DB_PASSWORD;\n    if (!databaseUsername) {\n        throw new Error(\"Please define the DB_USERNAME environment variable inside .env\");\n    }\n    if (!databasePassword) {\n        throw new Error(\"Please define the DB_PASSWORD environment variable inside .env\");\n    }\n    if (!connectionString) {\n        throw new Error(\"Please define the DB_CONN_STR environment variable inside .env\");\n    }\n    const cluster = await (0,couchbase__WEBPACK_IMPORTED_MODULE_0__.connect)(connectionString, {\n        username: databaseUsername,\n        password: databasePassword,\n        configProfile: \"wanDevelopment\"\n    });\n    return cluster;\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvbGliL2NvdWNoYmFzZS1jb25uZWN0aW9uLnRzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUE2QztBQUV0QyxlQUFlQztJQUNwQixNQUFNQyxtQkFBbUJDLFFBQVFDLEdBQUcsQ0FBQ0MsV0FBVztJQUNoRCxNQUFNQyxtQkFBbUJILFFBQVFDLEdBQUcsQ0FBQ0csV0FBVztJQUNoRCxNQUFNQyxtQkFBbUJMLFFBQVFDLEdBQUcsQ0FBQ0ssV0FBVztJQUVoRCxJQUFJLENBQUNILGtCQUFrQjtRQUNyQixNQUFNLElBQUlJLE1BQ1I7SUFFSjtJQUVBLElBQUksQ0FBQ0Ysa0JBQWtCO1FBQ3JCLE1BQU0sSUFBSUUsTUFDUjtJQUVKO0lBRUEsSUFBSSxDQUFDUixrQkFBa0I7UUFDckIsTUFBTSxJQUFJUSxNQUNSO0lBRUo7SUFFQSxNQUFNQyxVQUFVLE1BQU1YLGtEQUFPQSxDQUFDRSxrQkFBa0I7UUFDOUNVLFVBQVVOO1FBQ1ZPLFVBQVVMO1FBQ1ZNLGVBQWU7SUFDakI7SUFFQSxPQUFPSDtBQUNUIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2hhdC13aXRoLXBkZi8uL3NyYy9saWIvY291Y2hiYXNlLWNvbm5lY3Rpb24udHM/NWRiZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjb25uZWN0LCBDbHVzdGVyIH0gZnJvbSBcImNvdWNoYmFzZVwiO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlQ291Y2hiYXNlQ2x1c3RlcigpOiBQcm9taXNlPENsdXN0ZXI+IHtcbiAgY29uc3QgY29ubmVjdGlvblN0cmluZyA9IHByb2Nlc3MuZW52LkRCX0NPTk5fU1RSO1xuICBjb25zdCBkYXRhYmFzZVVzZXJuYW1lID0gcHJvY2Vzcy5lbnYuREJfVVNFUk5BTUU7XG4gIGNvbnN0IGRhdGFiYXNlUGFzc3dvcmQgPSBwcm9jZXNzLmVudi5EQl9QQVNTV09SRDtcblxuICBpZiAoIWRhdGFiYXNlVXNlcm5hbWUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBcIlBsZWFzZSBkZWZpbmUgdGhlIERCX1VTRVJOQU1FIGVudmlyb25tZW50IHZhcmlhYmxlIGluc2lkZSAuZW52XCJcbiAgICApO1xuICB9XG5cbiAgaWYgKCFkYXRhYmFzZVBhc3N3b3JkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgXCJQbGVhc2UgZGVmaW5lIHRoZSBEQl9QQVNTV09SRCBlbnZpcm9ubWVudCB2YXJpYWJsZSBpbnNpZGUgLmVudlwiXG4gICAgKTtcbiAgfVxuXG4gIGlmICghY29ubmVjdGlvblN0cmluZykge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIFwiUGxlYXNlIGRlZmluZSB0aGUgREJfQ09OTl9TVFIgZW52aXJvbm1lbnQgdmFyaWFibGUgaW5zaWRlIC5lbnZcIlxuICAgICk7XG4gIH1cblxuICBjb25zdCBjbHVzdGVyID0gYXdhaXQgY29ubmVjdChjb25uZWN0aW9uU3RyaW5nLCB7XG4gICAgdXNlcm5hbWU6IGRhdGFiYXNlVXNlcm5hbWUsXG4gICAgcGFzc3dvcmQ6IGRhdGFiYXNlUGFzc3dvcmQsXG4gICAgY29uZmlnUHJvZmlsZTogXCJ3YW5EZXZlbG9wbWVudFwiLFxuICB9KTtcblxuICByZXR1cm4gY2x1c3Rlcjtcbn1cbiJdLCJuYW1lcyI6WyJjb25uZWN0IiwiY3JlYXRlQ291Y2hiYXNlQ2x1c3RlciIsImNvbm5lY3Rpb25TdHJpbmciLCJwcm9jZXNzIiwiZW52IiwiREJfQ09OTl9TVFIiLCJkYXRhYmFzZVVzZXJuYW1lIiwiREJfVVNFUk5BTUUiLCJkYXRhYmFzZVBhc3N3b3JkIiwiREJfUEFTU1dPUkQiLCJFcnJvciIsImNsdXN0ZXIiLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwiY29uZmlnUHJvZmlsZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/lib/couchbase-connection.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/langchain","vendor-chunks/@opentelemetry","vendor-chunks/@langchain","vendor-chunks/formdata-node","vendor-chunks/openai","vendor-chunks/couchbase","vendor-chunks/semver","vendor-chunks/@ai-sdk","vendor-chunks/zod-to-json-schema","vendor-chunks/langsmith","vendor-chunks/form-data-encoder","vendor-chunks/es-errors","vendor-chunks/uuid","vendor-chunks/whatwg-url","vendor-chunks/qs","vendor-chunks/agentkeepalive","vendor-chunks/retry","vendor-chunks/p-queue","vendor-chunks/js-tiktoken","vendor-chunks/eventsource-parser","vendor-chunks/tr46","vendor-chunks/object-inspect","vendor-chunks/has-symbols","vendor-chunks/function-bind","vendor-chunks/call-bind","vendor-chunks/cmake-js","vendor-chunks/zod","vendor-chunks/node-fetch","vendor-chunks/mustache","vendor-chunks/ai","vendor-chunks/webidl-conversions","vendor-chunks/side-channel","vendor-chunks/set-function-length","vendor-chunks/secure-json-parse","vendor-chunks/p-timeout","vendor-chunks/p-retry","vendor-chunks/p-finally","vendor-chunks/ms","vendor-chunks/humanize-ms","vendor-chunks/hasown","vendor-chunks/has-proto","vendor-chunks/has-property-descriptors","vendor-chunks/gopd","vendor-chunks/get-intrinsic","vendor-chunks/eventemitter3","vendor-chunks/event-target-shim","vendor-chunks/es-define-property","vendor-chunks/define-data-property","vendor-chunks/decamelize","vendor-chunks/base64-js","vendor-chunks/abort-controller"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fchat%2Froute&page=%2Fapi%2Fchat%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fchat%2Froute.ts&appDir=%2FUsers%2Fshivaylamba%2FDesktop%2Fcb-projects%2Flivestream-new%2Fchat-with-pdf%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fshivaylamba%2FDesktop%2Fcb-projects%2Flivestream-new%2Fchat-with-pdf&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();