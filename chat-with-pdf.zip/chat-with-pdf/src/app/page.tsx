import Image from "next/image";
import { ChatWithPDF } from "../components/chat-with-pdf";

export default function Home() {
  return (
    <div className="font-sans">
    <ChatWithPDF />
   
    </div>
  );
}
